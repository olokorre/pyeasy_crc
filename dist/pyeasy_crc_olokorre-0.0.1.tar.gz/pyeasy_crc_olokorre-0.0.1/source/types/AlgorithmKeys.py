from typing import Literal

AlgorithmKeys = Literal['CRC-8', 'CDMA2000', 'DARC', 'DVB-S2', 'EBU', 'I-CODE', 'ITU', 'MAXIM', 'ROHC', 'WCDMA']
